package com.mezzofy.coupon.api.model;

import com.mezzofy.coupon.data.PromoUrlData;

public class PromoUrlModel {
	private PromoUrlData promourl;

	public PromoUrlData getPromourl() {
		return promourl;
	}

	public void setPromourl(PromoUrlData promourl) {
		this.promourl = promourl;
	}
}
