package com.mezzofy.coupon.data;


public class PromoDtlData {
	private String promoDtlId;
	private String promoId;
	private String promoUrlId;
	private String promoSurveyId;
	private String simplePromoId;
	public String getPromoDtlId() {
		return promoDtlId;
	}
	public void setPromoDtlId(String promoDtlId) {
		this.promoDtlId = promoDtlId;
	}
	public String getPromoId() {
		return promoId;
	}
	public void setPromoId(String promoId) {
		this.promoId = promoId;
	}
	public String getPromoUrlId() {
		return promoUrlId;
	}
	public void setPromoUrlId(String promoUrlId) {
		this.promoUrlId = promoUrlId;
	}
	public String getPromoSurveyId() {
		return promoSurveyId;
	}
	public void setPromoSurveyId(String promoSurveyId) {
		this.promoSurveyId = promoSurveyId;
	}
	public String getSimplePromoId() {
		return simplePromoId;
	}
	public void setSimplePromoId(String simplePromoId) {
		this.simplePromoId = simplePromoId;
	}
	
	

}
