package com.mezzofy.coupon.data;


public class ExternaldtlData {
	private String externalDtlId;
	private String externalId;
	private String campaignId;
	private String campaignCode;
	private String couponId;
	private String status;
	private String message;
	public String getExternalDtlId() {
		return externalDtlId;
	}
	public void setExternalDtlId(String externalDtlId) {
		this.externalDtlId = externalDtlId;
	}
	public String getExternalId() {
		return externalId;
	}
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}
	
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getCouponId() {
		return couponId;
	}
	public void setCouponId(String couponId) {
		this.couponId = couponId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCampaignId() {
		return campaignId;
	}
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}
	
}
