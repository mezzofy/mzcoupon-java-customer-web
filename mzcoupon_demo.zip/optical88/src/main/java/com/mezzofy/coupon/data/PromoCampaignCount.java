package com.mezzofy.coupon.data;

public class PromoCampaignCount {
	private String campaignId;
	private int campaignCount;
	public String getCampaignId() {
		return campaignId;
	}
	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}
	public int getCampaignCount() {
		return campaignCount;
	}
	public void setCampaignCount(int campaignCount) {
		this.campaignCount = campaignCount;
	}

}
