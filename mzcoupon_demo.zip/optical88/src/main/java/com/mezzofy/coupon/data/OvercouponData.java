package com.mezzofy.coupon.data;

public class OvercouponData {
 private int couponcount;
 
public int getCouponcount() {
	return couponcount;
}

public void setCouponcount(int couponcount) {
	this.couponcount = couponcount;
}
 
}
