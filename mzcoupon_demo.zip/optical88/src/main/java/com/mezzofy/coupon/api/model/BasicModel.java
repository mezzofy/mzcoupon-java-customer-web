package com.mezzofy.coupon.api.model;

import com.mezzofy.coupon.data.BasicData;

public class BasicModel {
	private BasicData basic;

	public BasicData getBasic() {
		return basic;
	}

	public void setBasic(BasicData basic) {
		this.basic = basic;
	}

	
}
