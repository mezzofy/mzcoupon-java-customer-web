package com.mezzofy.coupon.api.model;

import java.util.List;

import com.mezzofy.coupon.data.CurrencyData;

public class CurrencyListModel {

	private List<CurrencyData> currencies;

	public List<CurrencyData> getCurrencies() {
		return currencies;
	}

	public void setCurrencies(List<CurrencyData> currencies) {
		this.currencies = currencies;
	}

	
	
}
