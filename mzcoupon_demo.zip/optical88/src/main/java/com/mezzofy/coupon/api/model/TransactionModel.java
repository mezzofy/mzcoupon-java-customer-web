package com.mezzofy.coupon.api.model;

import com.mezzofy.coupon.data.TransactionData;

public class TransactionModel {
	TransactionData transaction;

	public TransactionData getTransaction() {
		return transaction;
	}

	public void setTransaction(TransactionData transaction) {
		this.transaction = transaction;
	}
	
	
}
