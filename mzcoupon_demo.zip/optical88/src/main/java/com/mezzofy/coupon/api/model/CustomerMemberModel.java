package com.mezzofy.coupon.api.model;

import java.util.List;

import com.mezzofy.coupon.data.CustomerMemberData;

public class CustomerMemberModel {
	
	private CustomerMemberData member;
	
	

	public CustomerMemberData getMember() {
		return member;
	}

	public void setMember(CustomerMemberData member) {
		this.member = member;
	}

	
	
	

}
