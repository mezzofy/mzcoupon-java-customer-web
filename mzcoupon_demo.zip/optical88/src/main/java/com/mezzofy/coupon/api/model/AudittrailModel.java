package com.mezzofy.coupon.api.model;

import com.mezzofy.coupon.data.AudittrailData;

public class AudittrailModel {
	private AudittrailData auditrail;

	public AudittrailData getAuditrail() {
		return auditrail;
	}

	public void setAuditrail(AudittrailData auditrail) {
		this.auditrail = auditrail;
	}
	
	
}
