package com.mezzofy.coupon.data;


public class DashboardData {
	private String monthname;
	private int issuedcount;
	private int redeemedcount;
	public String getMonthname() {
		return monthname;
	}
	public void setMonthname(String monthname) {
		this.monthname = monthname;
	}
	public int getIssuedcount() {
		return issuedcount;
	}
	public void setIssuedcount(int issuedcount) {
		this.issuedcount = issuedcount;
	}
	public int getRedeemedcount() {
		return redeemedcount;
	}
	public void setRedeemedcount(int redeemedcount) {
		this.redeemedcount = redeemedcount;
	}
	
	
	

}
