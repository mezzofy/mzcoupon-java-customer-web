package com.mezzofy.coupon.data;
public class CampaignSiteData {
	private String siteId;
		
	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	
}
