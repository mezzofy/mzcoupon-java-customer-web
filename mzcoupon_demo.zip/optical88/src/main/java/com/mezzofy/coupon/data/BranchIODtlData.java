package com.mezzofy.coupon.data;

public class BranchIODtlData {

	public String canonical_identifier;
	public String og_title;
	public String og_description;
	public String og_image_url;
	public String desktop_url;
	
	
	public String getCanonical_identifier() {
		return canonical_identifier;
	}
	public void setCanonical_identifier(String canonical_identifier) {
		this.canonical_identifier = canonical_identifier;
	}
	public String getOg_title() {
		return og_title;
	}
	public void setOg_title(String og_title) {
		this.og_title = og_title;
	}
	public String getOg_description() {
		return og_description;
	}
	public void setOg_description(String og_description) {
		this.og_description = og_description;
	}
	public String getOg_image_url() {
		return og_image_url;
	}
	public void setOg_image_url(String og_image_url) {
		this.og_image_url = og_image_url;
	}
	public String getDesktop_url() {
		return desktop_url;
	}
	public void setDesktop_url(String desktop_url) {
		this.desktop_url = desktop_url;
	}
	
	
	
	
}
