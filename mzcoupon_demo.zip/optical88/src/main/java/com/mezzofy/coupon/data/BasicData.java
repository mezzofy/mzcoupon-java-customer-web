package com.mezzofy.coupon.data;

public class BasicData {
	private String oauthId;
	private String oauthKey;
	private String oauthSecret;
	public String getOauthId() {
		return oauthId;
	}
	public void setOauthId(String oauthId) {
		this.oauthId = oauthId;
	}
	public String getOauthKey() {
		return oauthKey;
	}
	public void setOauthKey(String oauthKey) {
		this.oauthKey = oauthKey;
	}
	public String getOauthSecret() {
		return oauthSecret;
	}
	public void setOauthSecret(String oauthSecret) {
		this.oauthSecret = oauthSecret;
	}
	
	
}
