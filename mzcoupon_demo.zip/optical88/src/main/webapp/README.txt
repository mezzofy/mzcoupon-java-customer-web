Mezzofy - Readme.txt

===========================
Version: 1.0
Updated Date: DD MMM YYYY
===========================
- XXX